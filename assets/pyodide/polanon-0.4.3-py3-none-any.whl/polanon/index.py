"""Masking for search indexes: the documents, the questions, and the store of what tokens hide.

A retrieval-augmented application masks its documents before they are embedded and stored, and
masks every question the same way, so the question finds the passages about the same person. That
takes stable tokens, from an :class:`~polanon.Anonymizer` built with
:class:`~polanon.pseudonyms.Pseudonyms`. The masked passages go to the embedder and the index; what
each token stands for goes to a :class:`MappingStore`, which the application keeps apart from the
index, encrypted. Nothing that names a value is written to the index.

A passage found later is restored with the store, or exactly as written with the mapping kept for
it, and so is a model's answer, also while it streams.
"""

from __future__ import annotations

import re
import threading
from bisect import bisect_left, bisect_right
from collections.abc import Collection, Mapping, Sequence
from dataclasses import dataclass, replace
from typing import TYPE_CHECKING, NamedTuple, Protocol

from polanon import _canonical
from polanon._canonical import base_form
from polanon._known_parts import known_forms, known_parts
from polanon._matching import Ranges, type_of
from polanon._view import detection_view
from polanon.guards.base import Guard
from polanon.guards.names_pl import capital_tells_a_name, noun_surname_nominatives
from polanon.policy import TOKEN_PATTERN
from polanon.pseudonyms import PseudonymCollisionError, Pseudonyms
from polanon.stream_restore import tokens_written
from polanon.types import AnonymizationResult, MaskingUnavailableError, Span

if TYPE_CHECKING:
    from polanon import Anonymizer

_TOKEN_RE = re.compile(TOKEN_PATTERN)

#: Masking passes tried when the store reports collisions; each pass settles every one it reports.
_ATTEMPTS = 3

#: The types a text is looked up in the store for. Identifiers have checksums, labels and formats
#: the rules read anyway; a name in a question often has nothing but the store to go by.
_LOOKED_UP = ("PERSON", "ORG", "LOCATION")
#: The longest run of words looked up as one value.
_LONGEST = 4
_WORD = re.compile(r"[^\W\d_]+(?:['\u2019-][^\W\d_]+)*")
_GAP = re.compile(r"[ \t\u00a0]+")


@dataclass(frozen=True)
class StoredValue:
    """What a mapping store keeps for a token.

    Attributes:
        value: the value to show for the token: a person's name in the nominative, anything else
            as it was first written. Encrypt it at rest; it is the personal data.
        fingerprint: :meth:`Pseudonyms.fingerprint` of the value. It names nothing without the key,
            and two values with one token are told apart by it.
    """

    value: str
    fingerprint: str


class MappingStore(Protocol):
    """Where an application keeps what each token stands for, apart from its search index.

    Implement it over an encrypted table with a unique key on the token. ``add`` has to be atomic
    per token, so that two processes indexing at once cannot both claim a token for two values.
    """

    def get(self, tokens: Collection[str]) -> Mapping[str, StoredValue]:
        """Return what the store holds for each of `tokens` it has; leave the others out."""
        ...

    def add(self, entries: Mapping[str, StoredValue]) -> Mapping[str, StoredValue]:
        """Store each entry whose token is not held yet; return what is held for the others."""
        ...


class InMemoryMappingStore:
    """A :class:`MappingStore` in a dict, for tests, examples and a single process.

    It keeps the collision record too, so ``Pseudonyms(key, collisions=store.collisions)`` shares
    it. Everything is lost when the process ends.
    """

    def __init__(self) -> None:
        """Start empty."""
        self._entries: dict[str, StoredValue] = {}
        self._lock = threading.Lock()
        self.collisions: dict[str, str] = {}

    def get(self, tokens: Collection[str]) -> dict[str, StoredValue]:
        """Return what the store holds for each of `tokens` it has."""
        with self._lock:
            return {token: self._entries[token] for token in tokens if token in self._entries}

    def add(self, entries: Mapping[str, StoredValue]) -> dict[str, StoredValue]:
        """Store each entry whose token is not held yet; return what is held for the others."""
        held: dict[str, StoredValue] = {}
        with self._lock:
            for token, entry in entries.items():
                if token in self._entries:
                    held[token] = self._entries[token]
                else:
                    self._entries[token] = entry
        return held

    def __len__(self) -> int:
        """The number of tokens stored."""
        return len(self._entries)


@dataclass(frozen=True)
class MaskedChunks:
    """A document's passages, masked with one mapping.

    Attributes:
        texts: the masked passages, in order: what goes to the embedder and the index.
        mappings: for each passage, token -> the value as written in that passage. Kept with the
            passage (encrypted, outside the index), it restores the passage exactly as it was
            written, including the case a name stood in.
        mapping: every token of the document -> its first spelling.
    """

    texts: list[str]
    mappings: list[dict[str, str]]
    mapping: dict[str, str]


def tokens_in(*texts: str) -> set[str]:
    """Return every token that appears in `texts`, such as the passages a search found.

    A token a model wrote with a case, ``<OSOBA_1:wołacz>``, counts as the token it declines.
    """
    return {token for text in texts for token in tokens_written(text)}


def stored_mapping(store: MappingStore, *texts: str) -> dict[str, str]:
    """Return token -> value for every token in `texts` that the store holds, to restore them.

    Add the mapping of the question on the left, so a value only the question named restores too:
    ``question.mapping | stored_mapping(store, question.anonymized, *passages)``.
    """
    return {token: entry.value for token, entry in _get(store, tokens_in(*texts)).items()}


def mask_chunks(
    anonymizer: Anonymizer, chunks: str | Sequence[str], mapping: Mapping[str, str] | None = None
) -> MaskedChunks:
    """Mask the passages of one document with one mapping; see :meth:`Anonymizer.mask_chunks`.

    The passages are masked as one text, joined by blank lines, and cut apart again: masking each
    against the mapping of all the others took time that grew with the square of their number, and
    a value first recognised in a later passage is masked in the earlier ones all the same. A value
    that runs across two passages is masked in both, each piece under the value's token.
    """
    texts = _chunks(chunks)
    _no_judge(anonymizer, "mask_chunks")
    return _masked_chunks(anonymizer, texts, mapping)[0]


def _masked_chunks(
    anonymizer: Anonymizer, texts: Sequence[str], mapping: Mapping[str, str] | None
) -> tuple[MaskedChunks, AnonymizationResult]:
    """Mask the passages as one text; return them cut apart, and the result for the whole."""
    result = _mask(anonymizer, _joined(texts), dict(mapping or {}))
    masked, mappings = [], []
    replaced = _replaced(result)
    start = 0
    for text in texts:
        piece, written = _cut(result, start, start + len(text), replaced)
        masked.append(piece)
        mappings.append(written)
        start += len(text) + len(_PASSAGE_BREAK)
    return MaskedChunks(texts=masked, mappings=mappings, mapping=dict(result.mapping)), result


def index_chunks(
    anonymizer: Anonymizer,
    chunks: str | Sequence[str],
    store: MappingStore,
    *,
    lookup: bool = True,
) -> MaskedChunks:
    """Mask a document for an index and store its tokens; see :meth:`Anonymizer.index_chunks`."""
    pseudonyms = _pseudonyms(anonymizer, "index_chunks")
    texts = _chunks(chunks)
    for _ in range(_ATTEMPTS):
        joined = [_joined(texts)]
        wanted = _wanted(pseudonyms, joined) if lookup else {}
        held = _get(store, list(wanted)) if lookup else {}
        # Tokens the passages hold already, as when masked text is indexed again, are known
        # values: left whole, and restored as the store has them.
        before = stored_mapping(store, *texts)
        found = _found(anonymizer, pseudonyms, wanted, held)
        masked, result, entries = _index_pass(found, pseudonyms, texts, before)
        # A surname the document named by the full name is found alone in its other forms,
        # "Wróblowi" or "Wróbla", only by the lookup, which knew it only once it was stored. What
        # the document is about to store is looked up among the runs of words already read, and
        # where one lies outside everything masked, the document is masked once more with it.
        pending = {token: entry for token, entry in entries.items() if token in wanted}
        pending = {token: entry for token, entry in pending.items() if token not in held}
        if _left_in_the_clear(_hits(pseudonyms, wanted, pending)[0], result, joined[0]):
            found = _found(anonymizer, pseudonyms, wanted, {**held, **pending})
            masked, _, entries = _index_pass(found, pseudonyms, texts, before)
        # Asked first, so a pass that meets a collision writes nothing: written and then masked
        # again, a value moved to a longer token left its personal data under one nothing uses.
        if _record_collisions(pseudonyms, entries, _get(store, list(entries))):
            continue
        # Another process may have stored one of these tokens since; that pass is done again.
        if not _record_collisions(pseudonyms, entries, _add(store, entries)):
            _record_local_collisions(pseudonyms, masked.mapping)
            return masked
    raise PseudonymCollisionError(_TOO_MANY)


def mask_query(
    anonymizer: Anonymizer,
    text: str,
    store: MappingStore,
    mapping: Mapping[str, str] | None = None,
    *,
    lookup: bool = True,
) -> AnonymizationResult:
    """Mask a question to an index; see :meth:`Anonymizer.mask_query`."""
    pseudonyms = _pseudonyms(anonymizer, "mask_query")
    if not isinstance(text, str):
        raise TypeError(f"mask_query takes a str, not {type(text).__name__}")
    for _ in range(_ATTEMPTS):
        found = _with_store_hits(anonymizer, pseudonyms, [text], store) if lookup else None
        before = stored_mapping(store, text) | dict(mapping or {})
        result = _mask(found.masker if found else anonymizer, text, before)
        renamed = found.renames(result.mapping, before) if found else {}
        result = _renamed_result(result, renamed)
        # Tokens the conversation held before keep their values, collision or not: masking the
        # question again cannot change them, and refusing every later turn would help nobody.
        new = {t: v for t, v in result.mapping.items() if t not in before}
        entries = _entries(pseudonyms, new, _nominatives(renamed))
        held = _get(store, list(entries))
        if not _record_collisions(pseudonyms, entries, held):
            return result
    raise PseudonymCollisionError(_TOO_MANY)


_TOO_MANY = "the store kept reporting collisions; check that every process uses the same key"


def _get(store: MappingStore, tokens: Collection[str]) -> Mapping[str, StoredValue]:
    """Ask the store, naming a failure by its type only: a driver's message may quote values."""
    try:
        return store.get(tokens)
    except Exception as exc:
        raise MaskingUnavailableError(_store_failure(exc)) from exc


def _add(store: MappingStore, entries: Mapping[str, StoredValue]) -> Mapping[str, StoredValue]:
    """Write to the store, naming a failure by its type only."""
    try:
        return store.add(entries)
    except Exception as exc:
        raise MaskingUnavailableError(_store_failure(exc)) from exc


def _store_failure(exc: Exception) -> str:
    return (
        f"the mapping store failed with {type(exc).__name__}, so nothing may be indexed, sent or "
        "shown from it; the error is chained as the cause"
    )


def _chunks(chunks: str | Sequence[str]) -> list[str]:
    texts = [chunks] if isinstance(chunks, str) else list(chunks)
    for text in texts:
        if not isinstance(text, str):
            raise TypeError(f"a passage is a str, not {type(text).__name__}")
    return texts


def _no_judge(anonymizer: Anonymizer, method: str) -> None:
    if anonymizer.judge is not None:
        raise ValueError(
            f"{method} masks without an event loop, so it cannot run the stage-2 judge "
            f"{anonymizer.judge.name!r}: use an Anonymizer without a judge"
        )


def _pseudonyms(anonymizer: Anonymizer, method: str) -> Pseudonyms:
    _no_judge(anonymizer, method)
    if anonymizer.pseudonyms is None:
        raise ValueError(
            f"{method} needs stable tokens: build the Anonymizer with pseudonyms=Pseudonyms(key), "
            "or a question would never match the tokens of the documents"
        )
    return anonymizer.pseudonyms


def _mask(anonymizer: Anonymizer, text: str, mapping: dict[str, str]) -> AnonymizationResult:
    """Mask one text, refusing with MaskingUnavailableError instead of returning it half masked."""
    from polanon.turn import _failure  # the turn names failures the same way

    try:
        return anonymizer.anonymize_sync(text, mapping)
    except MaskingUnavailableError:
        raise
    except Exception as exc:
        raise MaskingUnavailableError(_failure(exc)) from exc


#: What the passages of a document are joined by to be masked as one text.
_PASSAGE_BREAK = "\n\n"


def _joined(texts: Sequence[str]) -> str:
    return _PASSAGE_BREAK.join(texts)


class _Replaced(NamedTuple):
    """Every masked range of a document, in order, with the token that replaced it."""

    ranges: list[tuple[int, int, str]]
    starts: list[int]
    ends: list[int]

    def within(self, start: int, end: int) -> list[tuple[int, int, str]]:
        """Return the ranges that overlap `start`..`end`, found by halving, not by reading all."""
        return self.ranges[bisect_right(self.ends, start) : bisect_left(self.starts, end)]


def _replaced(result: AnonymizationResult) -> _Replaced:
    """Return every masked range of the original text with the token that replaced it.

    Read once per document: each passage reading them all made a document of 3,200 passages
    take 19 s to cut where 800 took 1.4 s.
    """
    ranges: list[tuple[int, int, str]] = []
    shift = 0
    for span in result.spans:
        match = _TOKEN_RE.match(result.anonymized, span.start + shift)
        if match is None:  # pragma: no cover - every span was replaced by a token
            raise AssertionError("a masked span is not where its token is")
        ranges.append((span.start, span.end, match.group(0)))
        shift += len(match.group(0)) - (span.end - span.start)
    return _Replaced(ranges, [first for first, _, _ in ranges], [last for _, last, _ in ranges])


def _cut(
    result: AnonymizationResult, start: int, end: int, replaced: _Replaced
) -> tuple[str, dict[str, str]]:
    """Return one passage of a masked document, and token -> the value as the passage wrote it."""
    original = result.original
    pieces: list[str] = []
    written: dict[str, str] = {}
    cursor = start
    for first, last, token in replaced.within(start, end):
        first, last = max(first, start), min(last, end)
        if first >= last or not original[first:last].strip():
            continue  # outside the passage, or only the blank line between two
        pieces.append(original[cursor:first])
        pieces.append(token)
        written.setdefault(token, original[first:last])
        cursor = last
    pieces.append(original[cursor:end])
    passage = "".join(pieces)
    for token in tokens_in(passage):
        held = result.mapping.get(token)
        if token not in written and held is not None:
            written[token] = held  # a token the passage held already, or a placeholder
    return passage, written


def _entries(
    pseudonyms: Pseudonyms, mapping: Mapping[str, str], nominatives: Mapping[str, str]
) -> dict[str, StoredValue]:
    """Return what the store keeps for each token of a mapping; placeholders are left out.

    A token a surname's case took from the store, as in `nominatives`, is kept for the surname
    it stands for, as the store holds it: "Kozieł", not "Koziołowi".
    """
    entries: dict[str, StoredValue] = {}
    for token, value in mapping.items():
        entity_type = type_of(token)
        if entity_type is None or value == token:
            continue
        value = nominatives.get(token, value)
        entries[token] = StoredValue(
            base_form(value, entity_type), pseudonyms.fingerprint(value, entity_type)
        )
    return entries


class _Renamed(NamedTuple):
    """The token a lone surname's case takes from the store, and the surname it stands for."""

    token: str
    surname: str


def _nominatives(renamed: Mapping[str, _Renamed]) -> dict[str, str]:
    return {new.token: new.surname for new in renamed.values()}


def _swap_tokens(text: str, renamed: Mapping[str, _Renamed]) -> str:
    return _TOKEN_RE.sub(lambda match: _token_for(match[0], renamed), text)


def _token_for(token: str, renamed: Mapping[str, _Renamed]) -> str:
    new = renamed.get(token)
    return token if new is None else new.token


def _swap_keys(mapping: Mapping[str, str], renamed: Mapping[str, _Renamed]) -> dict[str, str]:
    """Return `mapping` with the tokens renamed; where two meet, the first spelling stays."""
    swapped: dict[str, str] = {}
    for token, value in mapping.items():
        swapped.setdefault(_token_for(token, renamed), value)
    return swapped


def _renamed_result(
    result: AnonymizationResult, renamed: Mapping[str, _Renamed]
) -> AnonymizationResult:
    if not renamed:
        return result
    return replace(
        result,
        anonymized=_swap_tokens(result.anonymized, renamed),
        mapping=_swap_keys(result.mapping, renamed),
    )


def _renamed_chunks(masked: MaskedChunks, renamed: Mapping[str, _Renamed]) -> MaskedChunks:
    if not renamed:
        return masked
    return MaskedChunks(
        texts=[_swap_tokens(text, renamed) for text in masked.texts],
        mappings=[_swap_keys(mapping, renamed) for mapping in masked.mappings],
        mapping=_swap_keys(masked.mapping, renamed),
    )


def _surnames(pseudonyms: Pseudonyms, mapping: Mapping[str, str]) -> dict[str, StoredValue]:
    """Return a store entry for the surname of every person in a mapping, written alone or not.

    A question names a person by the surname alone more often than a document does: "Co podpisał
    Kowalczyk?" after "Umowę podpisał Jan Kowalczyk." found nothing and sent the surname, since the
    store held only the full name. Only a surname next to a first name the rules know counts, as a
    guess of a language model is no evidence that the other word is a surname.
    """
    entries: dict[str, StoredValue] = {}
    for token, value in mapping.items():
        if type_of(token) != "PERSON" or value == token:
            continue
        for part in known_parts(value, "PERSON", trusted=False):
            entries.setdefault(
                pseudonyms.token(part, "PERSON"),
                StoredValue(base_form(part, "PERSON"), pseudonyms.fingerprint(part, "PERSON")),
            )
    return entries


def _record_collisions(
    pseudonyms: Pseudonyms, entries: Mapping[str, StoredValue], held: Mapping[str, StoredValue]
) -> bool:
    """Record every token the store holds for another value; return whether there was one."""
    found = False
    for token, entry in held.items():
        if token in entries and entry.fingerprint != entries[token].fingerprint:
            pseudonyms.record_collision(token, entry.fingerprint)
            found = True
    return found


def _record_local_collisions(pseudonyms: Pseudonyms, mapping: Mapping[str, str]) -> None:
    """Record the collisions one document settled itself, so every other text settles them alike.

    Two values of one document with one token were told apart there: the second got a longer token.
    Without a record, a question naming the second value alone would get the shorter one.
    """
    for token, value in mapping.items():
        entity_type = type_of(token)
        if entity_type is None or value == token:
            continue
        expected = pseudonyms.token(value, entity_type)
        owner = mapping.get(expected)
        if expected != token and owner is not None and owner != expected:
            pseudonyms.record_collision(expected, pseudonyms.fingerprint(owner, entity_type))


class _StoreHits(Guard):
    """Reports the values a text names that the mapping store already holds a token for."""

    name = "mapping_store"

    def __init__(self, hits: Mapping[str, list[Span]]) -> None:
        self._hits = hits

    def detect(self, text: str, enabled: set[str]) -> list[Span]:
        """Return the hits found in this text, whatever types are enabled: they are known values."""
        return list(self._hits.get(text, ()))


@dataclass(frozen=True)
class _Found:
    """What the store knows of a text: the anonymizer to mask it with, and the surnames' cases.

    `surnames` holds each lone word in a case the rules cannot read, lowercase, with the token of
    the one surname the store holds that it is a case of.
    """

    masker: Anonymizer
    surnames: Mapping[str, _Renamed]

    def renames(self, mapping: Mapping[str, str], before: Mapping[str, str]) -> dict[str, _Renamed]:
        """Return the new tokens of a masked mapping that take a stored surname's token instead.

        A word that is a case of a person the text or the conversation names, other than the one
        the store holds, stays that person's: after "Jan Kozioł", "Koziołowi" is his, not the
        stored Adam Kozieł's, and taking Kozieł's token joined the two in every search.
        """
        if not self.surnames:
            return {}
        people = [_Person.of(value) for token, value in mapping.items() if _named(token, value)]
        renamed: dict[str, _Renamed] = {}
        for token, value in mapping.items():
            word = value.strip().lower()
            new = self.surnames.get(word)
            if new is None or token in before or token == new.token or type_of(token) != "PERSON":
                continue
            surname = new.surname.lower()
            if all(surname in person.words for person in people if person.names(word)):
                renamed[token] = new
        return renamed


def _named(token: str, value: str) -> bool:
    """Whether a mapping holds a person's name of two words or more for `token`."""
    return type_of(token) == "PERSON" and value != token and len(value.split()) > 1


@dataclass(frozen=True)
class _Person:
    """A person a text names: the parts of the name and the forms of its surname, lowercase."""

    parts: frozenset[str]
    words: frozenset[str]

    @classmethod
    def of(cls, value: str) -> _Person:
        parts = {part.lower() for part in known_parts(value, "PERSON", trusted=False)}
        forms = {form.lower() for form in known_forms(value, "PERSON", trusted=False)}
        return cls(frozenset(parts), frozenset(parts | forms))

    def names(self, word: str) -> bool:
        """Whether a lowercase word is one of the person's words or a part with an ending."""
        return word in self.words or any(
            len(part) >= _SHORTEST_PART and word.startswith(part) for part in self.parts
        )


#: A part this long or longer names its person with an ending glued on: "Lisowi" is Lis's.
_SHORTEST_PART = 3


def _with_store_hits(
    anonymizer: Anonymizer, pseudonyms: Pseudonyms, texts: Sequence[str], store: MappingStore
) -> _Found:
    """Return the anonymizer with one more guard: the values of `texts` the store knows.

    A surname written alone, "Co podpisał Kowalczyk?", is a name no rule reads, and a question
    that sent it in the clear also found nothing. Its token is computed for every run of up to four
    words that could be a name, and the ones the store holds for the same value are masked like
    any detection, so the question gets the token the documents have. A capitalised word alone
    counts only when it is no bare first name, as a lowercase one never does.

    A surname in a case the rules cannot read, "Koziołowi" or "Kozieła" after "Adam Kozieł" was
    stored, is looked up by the nominatives it may come from, so it is masked as well, and it
    takes the stored surname's token, so a search for the person finds it: the store tells which
    of "Kozieł" and "Kozioł" the word is, where no rule could. Where the store holds two of them,
    or the word's own spelling, the word keeps the token that spelling gives.
    """
    wanted = _wanted(pseudonyms, texts)
    return _found(anonymizer, pseudonyms, wanted, _get(store, list(wanted)))


def _found(
    anonymizer: Anonymizer, pseudonyms: Pseudonyms, wanted: _Wanted, held: Mapping[str, StoredValue]
) -> _Found:
    """Return what `held` tells of the runs of `wanted`: the anonymizer, and the surnames' cases."""
    hits, surnames = _hits(pseudonyms, wanted, held)
    return _Found(_with_hits(anonymizer, hits), surnames)


def _with_hits(anonymizer: Anonymizer, hits: Mapping[str, list[Span]]) -> Anonymizer:
    """The anonymizer with the store's hits as one more guard, or as it is without any."""
    from polanon import Anonymizer as Facade  # the facade imports this module

    if not hits:
        return anonymizer
    return Facade(
        [*anonymizer.guards, _StoreHits(hits)],
        enabled=anonymizer.enabled,
        allowlist=anonymizer.allowlist,
        pseudonyms=anonymizer.pseudonyms,
    )


def _index_pass(
    found: _Found, pseudonyms: Pseudonyms, texts: Sequence[str], before: Mapping[str, str]
) -> tuple[MaskedChunks, AnonymizationResult, dict[str, StoredValue]]:
    """Mask a document's passages; return them, the result for the whole, and what to store."""
    masked, result = _masked_chunks(found.masker, texts, before)
    renamed = found.renames(masked.mapping, before)
    masked = _renamed_chunks(masked, renamed)
    entries = _entries(pseudonyms, masked.mapping, _nominatives(renamed))
    return masked, result, _surnames(pseudonyms, masked.mapping) | entries


def _left_in_the_clear(
    hits: Mapping[str, list[Span]], result: AnonymizationResult, text: str
) -> bool:
    """Whether a hit lies anywhere outside the ranges `result` masked in `text`.

    The hits are spans of the text as the guards read it, so a soft hyphen or a combining accent
    inside a surname does not hide it; each is taken back to the original and looked up among the
    masked ranges by halving, so a document of thousands of names costs no more than reading them.
    """
    if not hits:
        return False
    view = detection_view(text)
    masked = sorted((span.start, span.end) for span in result.spans)
    starts = [start for start, _ in masked]
    for spans in hits.values():
        for span in spans:
            hit = span if view is None else view.to_original(span)
            at = bisect_right(starts, hit.start) - 1
            if at < 0 or masked[at][1] < hit.end:
                return True
    return False


#: Token -> every run of words of a text that would get it: (the text as read, start, end, type,
#: and the value the token is of: the run as written, or a nominative it may be a case of).
_Wanted = dict[str, list[tuple[str, int, int, str, str]]]


def _wanted(pseudonyms: Pseudonyms, texts: Sequence[str]) -> _Wanted:
    """Return the token of every run of words in `texts` that could be a name, of each type.

    A lone word in a case the rules cannot read is wanted by the nominatives it may come from as
    well. The expensive part of a lookup, a keyed hash per run and type, so it is done once per
    text.
    """
    wanted: _Wanted = {}
    for text in texts:
        view = detection_view(text)
        seen = text if view is None else view.text
        for start, end in _candidates(seen):
            written = seen[start:end]
            for entity_type in _LOOKED_UP:
                token = pseudonyms.token(written, entity_type)
                wanted.setdefault(token, []).append((seen, start, end, entity_type, written))
            nominatives = _surnames_declined(written)
            # "Kozła widziałem" opens a sentence, "Sokołów Podlaski" is a town.
            if nominatives and capital_tells_a_name(seen, start, end):
                for surname in nominatives:
                    token = pseudonyms.token(surname, "PERSON")
                    wanted.setdefault(token, []).append((seen, start, end, "PERSON", surname))
    return wanted


def _hits(
    pseudonyms: Pseudonyms, wanted: _Wanted, held: Mapping[str, StoredValue]
) -> tuple[dict[str, list[Span]], dict[str, _Renamed]]:
    """Return the runs of `wanted` whose token `held` has for the same value, as spans per text.

    Also return each lone word found as a case of one stored surname only, lowercase, with that
    surname's token: a word found as written too, or as a case of two, keeps its own.
    """
    hits: dict[str, set[Span]] = {}
    as_written: set[str] = set()
    declined: dict[str, set[_Renamed]] = {}
    # A name is written many times in a document; its fingerprint is a keyed hash, taken once.
    fingerprints: dict[tuple[str, str], str] = {}
    for token, entry in held.items():
        for seen, start, end, entity_type, value in wanted.get(token, ()):
            key = (value, entity_type)
            if key not in fingerprints:
                fingerprints[key] = pseudonyms.fingerprint(*key)
            if fingerprints[key] != entry.fingerprint:
                continue
            hits.setdefault(seen, set()).add(Span(start, end, entity_type, 0.9, _StoreHits.name))
            word = seen[start:end].lower()
            if value == seen[start:end]:
                as_written.add(word)
            else:
                declined.setdefault(word, set()).add(_Renamed(token, value))
    surnames = {
        word: next(iter(found))
        for word, found in declined.items()
        if word not in as_written and len({new.token for new in found}) == 1
    }
    return {seen: sorted(spans) for seen, spans in hits.items()}, surnames


def _candidates(text: str) -> list[tuple[int, int]]:
    """Return every run of one to four words of `text` that could be a name, outside its tokens."""
    tokens = Ranges(match.span() for match in _TOKEN_RE.finditer(text))
    words = [
        match for match in _WORD.finditer(text) if not tokens.overlaps(match.start(), match.end())
    ]
    runs: list[tuple[int, int]] = []
    for first, word in enumerate(words):
        if _canonical._is_title(word.group(0)):
            continue  # "Pani Nowak" is looked up as "Nowak", so the title stays in the text
        for last in range(first, min(first + _LONGEST, len(words))):
            gap = text[words[last - 1].end() : words[last].start()]
            if last > first and _GAP.fullmatch(gap) is None:
                break
            if last > first or _could_be_named_alone(word.group(0)):
                runs.append((word.start(), words[last].end()))
    return runs


def _surnames_declined(written: str) -> list[str]:
    """Return the nominatives a lone word may be a case of, when the rules cannot read it.

    "Wróbla" or "Kowalczykowi" give their surname's token anyway, since the rules read them;
    "Koziołowi" gives "Kozieł", "Kozioł" and "Koziół" to look up.
    """
    if _WORD.fullmatch(written) is None or _canonical._surname(written):
        return []
    return noun_surname_nominatives(written)


def _could_be_named_alone(word: str) -> bool:
    """Whether one word on its own could be a value: capitalised, and no bare first name."""
    if len(word) < 3 or not word[0].isupper():
        return False
    return bool(_canonical._surname(word)) or not _canonical._first_name(word)
